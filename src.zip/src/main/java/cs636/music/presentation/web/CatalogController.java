package cs636.music.presentation.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Set;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import cs636.music.domain.Cart;
import cs636.music.domain.Product;
import cs636.music.service.CatalogService;
import cs636.music.service.data.CartItemData;
import cs636.music.service.data.UserData;
import cs636.music.presentation.web.SalesController;


/**
 * Ben Kwapong
 **/



@Controller
public class CatalogController {
	@Autowired
	private CatalogService catalogService;
	
	@Autowired
	private SalesController salesController;

	// String constants for URLs
	private static final String WELCOME_URL = "/welcome.html";
	private static final String WELCOME_VIEW = "/welcome";
	private static final String CATALOG_URL = "/catalog.html";
	private static final String CATALOG_VIEW = "/WEB-INF/jsp/catalog";
	private static final String PRODUCT_URL = "/product.html";
	private static final String PRODUCT_VIEW = "/WEB-INF/jsp/product";
	private static final String SOUND_URL = "/sound.html";
	private static final String SOUND_VIEW = "/WEB-INF/jsp/sound";
	private static final String CART_URL = "/cart.html";
	private static final String ADD_TO_CART_URL = "/addItemTOCart.html";
	private static final String UPDATE_CART_URL = "/updateCart.html";
	private static final String REMOVE_CART_ITEM_URL = "/removeCart.html";
	private static final String CART_VIEW = "/WEB-INF/jsp/cart";
	private static final String USERWELCOME_URL = "/userWelcome.html";
	private static final String USERWELCOME_VIEW = "/WEB-INF/jsp/userWelcome";
	private static final String LOGOUT_URL = "/logout.html";
	private static final String LOGOUT_VIEW = "/WEB-INF/jsp/logout";
	private static final String ADMINWELCOME_URL = "adminWelcome.html";
	private static final String ADMINWELCOME_VIEW = "/WEB-INF/adminController/adminWelcome";
	private static final String LISTVARIABLES_URL = "/listVariables.html";
	private static final String LISTVARIABLES_VIEW = "/WEB-INF/adminController/listVariables";



	@RequestMapping(WELCOME_URL)
	public String handleWelcome() {
		return WELCOME_VIEW;
	}
	
	@RequestMapping(CATALOG_URL)
	public String handleCatalog() {
		return CATALOG_VIEW;
	}

	@RequestMapping(USERWELCOME_URL)
	public String displayUserWelcome() throws ServletException {
		System.out.println("Checking out User Welcome");
		return USERWELCOME_VIEW;
	}
	
	@RequestMapping(LISTVARIABLES_URL)
	public String displayListVariables() throws ServletException {
		System.out.println("Checking out User Welcome");
		return LISTVARIABLES_VIEW;
	}
	
	@RequestMapping(ADMINWELCOME_URL)
	public String displayAdminWelcome() throws ServletException {
		System.out.println("Checking out User Welcome");
		return ADMINWELCOME_VIEW;
	}
	
	@RequestMapping(LOGOUT_URL)
	public String displayLogOut() throws ServletException {
		System.out.println("Checking out Login");
		return LOGOUT_VIEW; 
	}
	
	@RequestMapping(PRODUCT_URL)
	public String handleProductRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		HttpSession session = request.getSession();
		try {
			Product product = catalogService.getProductByCode(request.getParameter("pid"));
			request.setAttribute("product", product);
			session.setAttribute("product", product);
		} catch (Exception e) {
			throw new ServletException("Product getting  error: ", e);
		}
		return PRODUCT_VIEW;
	}

	// show cart page
	@RequestMapping(CART_URL)
	public String handleshowCartRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		HttpSession session = request.getSession();
		Cart cart = (Cart) session.getAttribute("cart");
		try {
			if (cart == null || catalogService.getCartInfo(cart).isEmpty()) {
				request.setAttribute("cartItem", null);
			} else {
				Set<CartItemData> cartItems = catalogService.getCartInfo(cart);
				request.setAttribute("cartItem", cartItems);
			}
		} catch (Exception e) {
			throw new ServletException("show cart error: ", e);
		}
		return CART_VIEW;
	}

	@RequestMapping(ADD_TO_CART_URL)
	public String handleAddCartItemRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		HttpSession session = request.getSession();
		Cart cart = (Cart) session.getAttribute("cart");

		long productId = Long.parseLong(request.getParameter("productId"));

		try {
			if (cart == null)
				cart = catalogService.createCart();
			int quantity = 1;
			catalogService.addItemtoCart(productId, cart, quantity);
			Set<CartItemData> cartItems = catalogService.getCartInfo(cart);
			request.setAttribute("cartItem", cartItems);
		} catch (Exception e) {
			throw new ServletException("add item to cart error: ", e);
		}
		session.setAttribute("cart", cart);
		return CART_VIEW;
	}

	@RequestMapping(UPDATE_CART_URL)
	public String handleUpdateCartRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		long productId = Long.parseLong(request.getParameter("productId"));
		HttpSession session = request.getSession();
		Cart cart = (Cart) session.getAttribute("cart");

		try {

			if (quantity < 0)
				quantity = 1;
		} catch (NumberFormatException ex) {
			quantity = 1;
		}
		try {
			catalogService.changeCart(productId, cart, quantity);
			Set<CartItemData> cartItems = catalogService.getCartInfo(cart);
			request.setAttribute("cartItem", cartItems);
		} catch (Exception e) {
			throw new ServletException("update cart error i dont know what is wrong: ", e);
		}
		return CART_VIEW;
	}

	@RequestMapping(REMOVE_CART_ITEM_URL)
	public String handleRemoveCartItemRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		long productId = Long.parseLong(request.getParameter("productId"));
		HttpSession session = request.getSession();
		Cart cart = (Cart) session.getAttribute("cart");
		try {
			catalogService.removeCartItem(productId, cart);
			Set<CartItemData> cartItems = catalogService.getCartInfo(cart);
			request.setAttribute("cartItem", cartItems);

		} catch (Exception e) {
			throw new ServletException("cart error while removing item ", e);
		}
		return CART_VIEW;
	}
	

	@RequestMapping(SOUND_URL)
	public String handleSoundPageRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		HttpSession session = request.getSession();
		UserData user = (UserData) session.getAttribute("user");
		String productCode = request.getParameter("productcode");

		 if (user == null) {
		 session.setAttribute("parent",
		 "/sound.html?productcode="+productCode);
		 session.setAttribute("productCode", productCode);
		 return salesController.handleRegisterRequest(request, response);
		 } else {
		
		try {
			Product product = (Product) catalogService.getProductByCode(productCode);
			session.setAttribute("product", product);
			request.setAttribute("product", product);
		} catch (Exception e) {
			throw new ServletException("cart error while accessing product from cart ", e);
		}
		return SOUND_VIEW;
		}
	}

}
