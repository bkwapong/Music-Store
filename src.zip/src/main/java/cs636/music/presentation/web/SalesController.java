package cs636.music.presentation.web;

import java.io.IOException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import cs636.music.service.CatalogService;
import cs636.music.service.SalesService;
import cs636.music.service.data.InvoiceData;
import cs636.music.service.data.UserData;
import cs636.music.domain.Cart;
import cs636.music.domain.Product;


@Controller
public class SalesController {
	@Autowired
	private SalesService salesService;	
	
	@Autowired
	private CatalogService catalogService;
	
	private static final String REGISTER_URL = "/register.html";
	private static final String REGISTER_VIEW = "/WEB-INF/jsp/register";
	private static final String REGISTERCHECKOUT_URL = "/register-checkout.html";
	private static final String REGISTERCHECKOUT_VIEW = "/WEB-INF/jsp/register_checkout";
	private static final String COMPLETE_URL = "/complete.html";
	private static final String COMPLETE_VIEW = "/WEB-INF/jsp/complete";
	private static final String CHECKOUT_URL = "/checkout.html";
	private static final String CHECKOUT_VIEW = "/WEB-INF/jsp/invoice";
	
	
	@RequestMapping(REGISTER_URL)
	public String handleRegisterRequest(HttpServletRequest request,
            HttpServletResponse response) throws IOException, ServletException {

        String firstName = request.getParameter("firstName");        
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email"); 
        String address = request.getParameter("address");
        String productCode = request.getParameter("productcode");
        HttpSession session = request.getSession();
        
       try{
        	salesService.registerUser(firstName, lastName, email);        	
        	UserData user = salesService.getUserInfoByEmail(email);
        	salesService.addUserAddress(user.getId(), address);
        	request.setAttribute("user", user);
        	request.getSession().setAttribute("user",user);
        }catch (Exception e){
        	
        	return REGISTER_VIEW;
        	
        }
       
       try {
			Product product = (Product) catalogService.getProductByCode(productCode);
			session.setAttribute("product", product);
			request.setAttribute("product", product);
		} catch (Exception e) {
			throw new ServletException("update cart error: ", e);
		}

       
        String url = "/WEB-INF/jsp/sound";
        return url;      
    }
	
	@RequestMapping(REGISTERCHECKOUT_URL)
	public String handleRegisterCheckout(HttpServletRequest request,
            HttpServletResponse response) throws IOException, ServletException {

        String firstName = request.getParameter("firstName");        
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email"); 
        String address = request.getParameter("address");
        
       try{
        	salesService.registerUser(firstName, lastName, email);        	
        	UserData user = salesService.getUserInfoByEmail(email);
        	salesService.addUserAddress(user.getId(), address);
        	request.setAttribute("user", user);
        	request.getSession().setAttribute("user",user);
        }catch (Exception e){
        	
        	return REGISTERCHECKOUT_VIEW;
        	
        }
       return "/WEB-INF/jsp/catalog";     
    }
	
	@RequestMapping(CHECKOUT_URL)
	public String handleCheckOutRequest(HttpServletRequest request,
            HttpServletResponse response) throws IOException, ServletException{

        HttpSession session = request.getSession();        
        UserData user = (UserData) session.getAttribute("user");
        if(user == null )
        {	
        	return handleRegisterCheckout(request, response);
        }
        
        Cart cart = (Cart) session.getAttribute("cart");
        System.out.println(cart.getItems());
        System.out.println(user.getId());
        try{
        	if(cart != null)
        	{
        		InvoiceData invoice = salesService.checkout(cart, user.getId());
        		user = salesService.getUserInfo(user.getId()); 
        		session.setAttribute("invoice", invoice);
        		session.setAttribute("userAddress", user);
        		request.setAttribute("invoice", invoice);        		
        		request.setAttribute("user", session.getAttribute("user"));
        		
        	}
        	 } catch (Exception e) {
        	 throw new ServletException("check out  error: ", e);
        	 }
        return CHECKOUT_VIEW;
    }
	
	@RequestMapping(COMPLETE_URL)
	public String handleCompleteOrderRequest(HttpServletRequest request,
            HttpServletResponse response) throws IOException, ServletException{
		
		request.setAttribute("user", request.getSession().getAttribute("user"));
		System.out.println(request.getSession().getAttribute("user"));
		return COMPLETE_VIEW;
	}

}
