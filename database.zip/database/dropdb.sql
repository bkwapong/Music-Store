--drop targets of FKs after tables with the FKs
drop table download;
drop table track; 
drop table lineitem;
drop table product;
drop table invoice;
drop table site_user;
drop table userpass;
drop table userrole;
drop table music_sys_tab;






