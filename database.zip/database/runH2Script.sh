java -cp lib-for-ant/h2.jar org.h2.tools.RunScript -url jdbc:h2:~/test-music3 -user test -script $1 -showResults

